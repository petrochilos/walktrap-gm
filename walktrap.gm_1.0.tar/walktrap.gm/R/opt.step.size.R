opt.step.size <-
function(testNet, wtcMerges, vweights, dist, threshold, modularity ) {
#FIND BEST STEP SIZE  
stop = 0  
comm.scores <- c(0)    
step.size <- round(.2 * (length(V(testNet))))  
increment <- round(.005 * (length(V(testNet))))  

while (step.size <= (length(V(testNet)))) {   
    comm.steps <- c(0)  
    comm.memb <-  community.to.membership(testNet, wtcMerges, steps=step.size,   membership=TRUE, csize=TRUE)  
    community.vector <-  which(comm.memb$csize > 3) -1  
    all.comm.means <- c(0)   
    if(max(comm.memb$csize) <= threshold) {  
        for (i in community.vector) { 
            comm.size <- comm.memb$csize[i +1]  
            comm.total.mean <- mean(vweights [which(comm.memb$memb == i)]^2)   
            comm.total.tscore <- abs(comm.total.mean - mean((dist [comm.memb$csize[i +1],]^2)))/sqrt(var((dist [comm.memb$csize[i +1],]^2)))    
            all.comm.means <- c(all.comm.means, comm.total.tscore)  
        }  
    }   
    else {}  
  
comm.scores[step.size] <- max(all.comm.means)  
step.size <- step.size + increment  
}   
 
 #CHECK OPTIMAL STEP SIZE AGAINST MODULARITY  
optStepSize <- max(which(comm.scores == max(comm.scores, na.rm=TRUE))) 
if (optStepSize > which.max(modularity)-1) {optStepSize <- which.max(modularity)-1}
  

return (optStepSize )
}
