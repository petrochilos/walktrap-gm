calc.weights <-
function(testNet, vGS, vFC) {# matrix with col1 =vector of gene symbols, col2 =vector of normalized FC values 
#CALCULATE VERTEX WEIGHTS  

vertexNames <- testNet[9][[1]][[3]][[1]]  

vweights <- c()  
count = 0  
for (i in vertexNames) {   
    count = count +1  
    if (length(which(vGS == i)) >0)  {  
        vweights [count] <- max(abs(vFC[which(vGS == i),]))}  
    else { vweights [count] <- .01}  
    }  

dist <- matrix (ncol = 5000, nrow = 200)  
for (i in 3:200) {  
    drawsDS1 <- matrix(sample(vweights, size = i * 5000, replace = TRUE), i)  
    drawmeansDS1 <- apply(drawsDS1, 2, mean)  
    dist [i,] <- drawmeansDS1  
}  


#CALCULATE EDGE WEIGHTS  

globalEdges <- get.edgelist(testNet, names=TRUE)
eweights <- c()  
for (i in 1:length(globalEdges[,1])) {   
tempEdge1 <- globalEdges[i,1]  
   tempEdge2 <-  globalEdges[i,2]  
 if ((length(which(vGS == tempEdge1)) >0)  || (length(which(vGS == tempEdge2)) >0)) {  
        if ((length(which(vGS == tempEdge1)) >0)  && (length(which(vGS == tempEdge2)) >0)) {  
             eweights[i] <- (max(abs(vFC[which(vGS == tempEdge1),])) + max(abs(vFC[which(vGS == tempEdge2),])))/2}  
        else if  ((length(which(vGS == tempEdge1)) >0)) {  
            eweights[i] <- (max(abs(vFC[which(vGS == tempEdge1),])))/2}  
        else if ((length(which(vGS == tempEdge2)) >0)) {  
            eweights[i] <- (max(abs(vFC[which(vGS == tempEdge2),])))/2}  
        else { eweights[count] <- .01}  
    }  
}  

eweights [is.na(eweights)] <- .01

weightLists  <- list("vweights" = vweights, "dist" =  dist, "eweights"= eweights )  
return(weightLists)  

}
