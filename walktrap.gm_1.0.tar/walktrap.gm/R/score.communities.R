score.communities <-
function(optSize, testNet, wtcMerges, vweights, dist) {
  
#RUN BEST MODEL
comm.struct <- community.to.membership(testNet,  wtcMerges, steps=optSize, membership=TRUE, csize=TRUE)  

#ARCHIVE SCORES FOR BEST MODEL
resMat <-  matrix(ncol=3)  
 community.vector <-  which(comm.struct$csize > 3) -1    
     all.comm.means <- c(0)  
     for (i in community.vector) {  
        cancerScores <- cancerVertexWeights[which(comm.struct$memb == i)]  
        cmean <- mean(cancerScores)  
        comm.total.mean <-  mean((vweights[which(comm.struct$memb ==i)]^2))   
        comm.total.tscore <- abs(comm.total.mean -mean((dist[comm.struct$csize[i +1],])^2))/sqrt(var((dist[comm.struct$csize[i +1],])^2))  
        resMat <- rbind(resMat, c(i, comm.total.tscore, comm.struct$csize[i +1]))  
        all.comm.means <- c(all.comm.means, comm.total.zscore)  
}  

colnames(resMat) <- c("ID", "Score", "Size")
return(resMat) 
}
